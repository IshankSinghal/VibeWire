import { createContext } from "react";

export const UpdateContextStorage = createContext(null);
